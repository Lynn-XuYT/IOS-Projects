//
//  YTBaseContactViewController.h
//  IOS作业
//
//  Created by Lynn on 15/12/31.
//  Copyright © 2015年 xu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YTBaseContactViewController : UIViewController
@property (strong, nonatomic) UITextField *nameField;
@property (strong, nonatomic) UITextField *phoneField;
@property (strong, nonatomic) UIButton *btn;
@end
