//
//  YTOtherViewController.h
//  IOS作业
//
//  Created by Lynn on 15/12/31.
//  Copyright © 2015年 xu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YTOtherViewController : UIViewController

@end
