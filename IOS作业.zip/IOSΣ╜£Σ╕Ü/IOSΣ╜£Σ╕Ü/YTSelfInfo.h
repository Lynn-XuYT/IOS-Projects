//
//  YTSelfInfo.h
//  IOS作业
//
//  Created by Lynn on 15/12/31.
//  Copyright © 2015年 xu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YTSelfInfo : NSObject<NSCopying>

@property(nonatomic, copy)NSString *iconName;
@property(nonatomic, copy)NSString *title;
@property(nonatomic, copy)NSString *subTitle;

@end
