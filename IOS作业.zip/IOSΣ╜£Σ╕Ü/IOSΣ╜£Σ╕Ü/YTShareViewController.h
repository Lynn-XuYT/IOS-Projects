//
//  YTShareViewController.h
//  IOS作业
//
//  Created by Lynn on 15/12/29.
//  Copyright © 2015年 xu. All rights reserved.
//

#import "YTBaseViewController.h"

@interface YTShareViewController : YTBaseViewController

@end
