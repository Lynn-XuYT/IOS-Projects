//
//  YTMemo.h
//  IOS作业
//
//  Created by Lynn on 15/12/30.
//  Copyright © 2015年 xu. All rights
//

#import <Foundation/Foundation.h>

@interface YTMemo : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *substitle;
@property (nonatomic, copy) NSString *time;
@end
